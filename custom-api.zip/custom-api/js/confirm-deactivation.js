jQuery(document).ready(function($) {
    $('.delete-custom-plugin').on('click', function(e) {
        e.preventDefault();
        var deactivationUrl = $(this).attr('href');

        var confirmed = confirm("Da li želite da obrišete tabelu?");
        if (confirmed) {
            // Ako korisnik potvrdi, šaljemo zahtev da se obriše tabela
            $.post(custom_vars.ajax_url, {
                action: "delete_custom_table"
            }, function(response) {
                // Nakon uspešnog brisanja tabele, deaktiviramo plugin
                window.location.href = deactivationUrl;
            });
        } else {
            window.location.href = deactivationUrl;
        }
    });
});
