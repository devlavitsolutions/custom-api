<?php

function logs_api_create_table(){
    global $wpdb;

    $table_name = $wpdb->prefix . 'api_logs';

    $existens = $wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") == $table_name;

    if(!$existens){
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            api_endpoint text NOT NULL,
            api_method text NOT NULL,
            user_agent text,
            ip_address varchar(100) NOT NULL,
            request_data text,
            timestamp datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}

function logs_api_drop_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'api_logs';

    $existens = $wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") == $table_name;

    if($existens){
        $result = $wpdb->query("DROP TABLE IF EXISTS $table_name");
        if ($result === false) {
            error_log("Error dropping table: " . $wpdb->last_error);
        } else {
            error_log("Number of rows affected: " . $result);
        }
    }
   
}
