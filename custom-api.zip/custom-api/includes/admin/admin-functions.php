<?php

require_once(plugin_dir_path(__FILE__) . 'api-log-list-table.php');

///////////// SETTINGS ///////////////////


function custom_api_menu_page() {
    add_menu_page(
        'Custom API Settings',
        'Custom API',
        'manage_options',
        'custom-api-settings',
        'custom_api_settings_page_html'
    );
}

function custom_api_settings_page_html() {
    if (!current_user_can('manage_options')) {
        return;
    }

    if (isset($_GET['settings-updated'])) {
        add_settings_error('custom_api_messages', 'custom_api_message', 'Postavke su sačuvane', 'updated');
    }

    settings_errors('custom_api_messages');
    ?>
    <div class="wrap">
        <h1><?= esc_html(get_admin_page_title()); ?></h1>
        <form action="" method="post">
            <?php
            settings_fields('custom_api');
            do_settings_sections('custom-api-settings');
            ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="custom_api_variable_name">Ime varijable</label></th>
                    <td><input type="text" name="custom_api_variable_name"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="custom_api_variable_value">Vrednost varijable</label></th>
                    <td><input type="text" name="custom_api_variable_value" ></td>
                </tr>
            </table>
            <?php
            submit_button('Sačuvaj postavke');
            ?>
        </form>
    </div>
    <?php
}

if (isset($_POST['submit'])) {
    save_custom_api_settings();
}



function custom_api_settings_init() {
    register_setting('custom_api', 'custom_api_key');


    add_settings_section(
        'custom_api_section',
        'Custom API Postavke',
        'custom_api_section_callback',
        'custom-api-settings'
    );

    add_settings_field(
        'custom_api_key_field',
        'API ključ',
        'custom_api_key_field_callback',
        'custom-api-settings',
        'custom_api_section'
    );

    add_settings_field(
        'custom_api_variable_field',
        'Ime i vrednost varijable',
        'custom_api_variable_field_callback',
        'custom-api-settings',
        'custom_api_section'
    );

}


function custom_api_section_callback() {
    echo 'Unesite vaše postavke ispod:';
}

function custom_api_variable_field_callback() {
}

function custom_api_key_field_callback() { 
    echo '<input type="text" name="custom_api_key">';
}

function save_custom_api_settings() {

    if (isset($_POST['custom_api_variable_name']) && isset($_POST['custom_api_variable_value'])) {
        $name = sanitize_text_field($_POST['custom_api_variable_name']);
        $value = sanitize_text_field($_POST['custom_api_variable_value']);

        if (!empty($name) && !empty($value)) {
            global $wpdb;

            $table_name = $wpdb->prefix . 'api_settings'; 

            $existing_variable = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT * FROM $table_name WHERE name = %s AND value = %s", $name, $value
                ));

            if ($existing_variable){
                $error = new WP_Error('duplicate_variable', 'Varijabla sa istim imenom i vrednošću već postoji.');
                wp_die($error);
            }
            

            $data = array(
                'name' => $name,
                'value' => $value,
            );

            $format = array(
                '%s',
                '%s', 
            );

            $wpdb->insert($table_name, $data, $format);
        }
    }
}


function custom_api_submenu_page() {
    add_submenu_page(
        'custom-api-settings',
        'API Logovi',
        'API Logovi',
        'manage_options',
        'api-logs',
        'render_api_log_page'
    );
}


function render_api_log_page() {
    $apiLogTable = new API_Log_List_Table();
    $apiLogTable->prepare_items();
    
    echo '<div class="wrap"><h1>API Logovi</h1>';
    $apiLogTable->display();
    echo '</div>';
}

/////////////// EDIT I DELETE ///////////////////

function custom_api_delete_edit_submenu_page() {
    add_submenu_page(
        null, // Ne želimo da se ova stranica prikaže u meniju, pa koristimo null
        'Uredi API Log',
        'Uredi API Log',
        'manage_options',
        'edit-api-log',
        'custom_api_edit_log_page' // Ovo je funkcija koju ste definisali za prikazivanje forme za uređivanje
    );

    add_submenu_page(
        null, // Ne želimo da se ova stranica prikaže u meniju, pa koristimo null
        'Obriši API Log',
        'Obriši API Log',
        'manage_options',
        'delete-api-log',
        'custom_api_delete_log' // Ovo je funkcija koju trebate definisati za obradu brisanja
    );
}

function custom_api_delete_log(){
    global $wpdb;

    // Provera da li je zahtev za brisanje i da li je na pravoj stranici
    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id']) && isset($_GET['page']) && $_GET['page'] == 'delete-api-log') {
        $id = intval($_GET['id']);
        $wpdb->delete($wpdb->prefix . 'custom_api_logs', ['id' => $id]);

        wp_redirect(admin_url('admin.php?page=api-logs')); // Preusmjeravanje natrag na stranicu s logovima
        exit;
    }
}

function custom_api_edit_log_page() {

    global $wpdb;


    if (!current_user_can('manage_options')) {
        wp_die('Sorry, you are not allowed to access this page. PROVERA');
    }
    
    if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $log = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}api_logs WHERE id = %d", $id), ARRAY_A);



        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = array(
                'ip_address'    => $_POST['ip_address'],
                'api_endpoint'  => $_POST['api_endpoint'],
                'api_method'    => $_POST['api_method'],
                'request_data'  => $_POST['request_data'],
                'timestamp'     => $_POST['timestamp'],
            );

            $where = array('id' => $id);
            $wpdb->update("{$wpdb->prefix}api_logs", $data, $where);

            echo "Zapis je uspešno ažuriran!";
        }

        // Prikaz forme za uređivanje
        ?>
        <form method="post">
            IP Address: <input type="text" name="ip_address" value="<?php echo esc_attr($log['ip_address']); ?>"><br>
            API Endpoint: <input type="text" name="api_endpoint" value="<?php echo esc_attr($log['api_endpoint']); ?>"><br>
            API Method: <input type="text" name="api_method" value="<?php echo esc_attr($log['api_method']); ?>"><br>
            Request Data: <textarea name="request_data"><?php echo esc_textarea($log['request_data']); ?></textarea><br>
            Time: <input type="text" name="timestamp" value="<?php echo esc_attr($log['timestamp']); ?>"><br>
            <input type="submit" value="Sačuvaj izmene">
        </form>
        <?php

    

    } else {
        echo "ID nije pronađen!";
        return;
    }
}



////////////////// DELETING TABLE ////////////////////////////////////
function custom_enqueue_admin_scripts($hook) {
    if ('plugins.php' !== $hook) {
        return;
    }
    wp_enqueue_script('custom-confirm-deactivation', 'http://localhost/wp/wp-content/plugins/clanak-api/js/confirm-deactivation.js', array('jquery'), '1.0.0', true);
}

function custom_localize_script() {
    wp_localize_script('custom-confirm-deactivation', 'custom_vars', array(
        'admin_url' => admin_url(),
        'ajax_url'  => admin_url('admin-ajax.php')
    ));
}

function custom_add_deactivation_class($links) {
    if (isset($links['deactivate'])) {
        $links['deactivate'] = str_replace('<a ', '<a class="delete-custom-plugin" ', $links['deactivate']);
    }
    return $links;
}

function ajax_delete_custom_table() {
    logs_api_drop_table();
    wp_send_json_success();
}


?>