<?php

if (!class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

class API_Log_List_Table extends WP_List_Table {

    function __construct() {
        parent::__construct([
            'singular' => 'API Log',
            'plural'   => 'API Logs',
            'ajax'     => false
        ]);
    }

    function get_columns() {
        return [
            'id'            => 'ID',
            'ip_address'    => 'IP Address',
            'api_endpoint'  => 'Endpoint',
            'api_method'    => 'Method',
            'request_data'  => 'Request Data',
            'timestamp'          => 'Timestamp',
            'actions'       => 'Actions'
        ];
    }

    function prepare_items() {
        global $wpdb;

        $this->_column_headers = [$this->get_columns(), [], []];
        $this->items = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}api_logs", ARRAY_A);
    }

    function column_default($item, $column_name) {
        switch ($column_name) {
            case 'id':
            case 'ip_address':
            case 'api_endpoint':
            case 'api_method':
            case 'time':
                return $item[$column_name];
            case 'actions':
                return $this->column_actions($item);
            default:
                return print_r($item, true);
        }
    }

    function column_actions($item) {
        $edit_link = admin_url('admin.php?page=edit-api-log&action=edit&id=' . $item['id']);
        $delete_link = admin_url('admin.php?page=delete-api-log&action=delete&&id=' . $item['id']);
        return sprintf('<a href="%s" class="button">Edit</a> <a href="%s" class="button delete">Delete</a>', $edit_link, $delete_link);
    }
    
}
