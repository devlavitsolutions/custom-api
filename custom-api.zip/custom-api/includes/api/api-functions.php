<?php

//// REGISTROVANJE ENDPOINTA

function register_api_endpoints() {
    register_rest_route('custom-api', '/createpost', array(
        'methods'  => 'POST',
        'callback' => 'create_clanak_from_post',
        'permission_callback' => '__return_true'
    ));

    register_rest_route('custom-api', '/register', array(
        'methods' => 'POST',
        'callback' => 'register_user',
    ));

    register_rest_route('custom-api', '/weebhook', array(
        'methods' => 'POST',
        'callback' => 'handle_webhook_request',
    ));
}

//// KREIRANJE CLANKA PREKO API

function create_clanak_from_post(WP_REST_Request $request){

    if (check_verification($request)){

        log_api_request($request);  // Logovanje podataka
   
        $content = urldecode($request->get_param('content'));
        $title = urldecode($request->get_param('title'));

        if(empty($content) || empty($title)){
            return new WP_Error('empty_fields', 'Title or Content empty', array('status' => 400));
        }

        // Kreiranje clanka

        $post_id = wp_insert_post(array(
        'post_title'        =>      sanitize_text_field($title),
        'post_content'      =>      sanitize_post_field('post_content', $content, 0, 'db'),
        'post_status'       =>      'publish',
        'post_type'         =>      'post'
        ));

        if ( is_wp_error( $post_id ) ) {
            return $post_id;
        }

        return array('status' => 'success', 'post_id' => $post_id);

    }else{
        return new WP_Error('unauthorized', 'Unauthorized', array('status' => 401));
    }

}

//// LOGOVANJE API U BAZU

function log_api_request($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'api_logs';
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $ip_address = $_SERVER['REMOTE_ADDR'];

    $wpdb->insert($table_name, array(
        'api_endpoint' => $request->get_route(),
        'api_method'   => $request->get_method(),
        'user_agent'   => $user_agent,
        'ip_address'   => $ip_address,
        'request_data' => json_encode($request->get_params()),
        'timestamp'    => current_time('mysql')
    ));
}

///// REGISTROVANJE PREKO API

function register_user($request){


    if (check_verification($request)){

        $username = sanitize_user($request->get_param('username'));
        $email = sanitize_email($request->get_param('email'));
        $password = $request->get_param('password');

        if (email_exists($email)) {
            return new WP_Error('email_exists', 'Email already exists', array('status' => 400));
        }

        if (username_exists($username)) {
            return new WP_Error('username_exists', 'Username already exists', array('status' => 400));
        }

        // Kreiranje korisnika
        $user_id = wp_create_user($username, $password, $email);

        if (is_wp_error($user_id)) {
            return $user_id;
        }

        return array('status' => 'success', 'user_id' => $user_id);

    }else{
        return new WP_Error('unauthorized', 'You need to register as a API user first, check localhost/wp/registracija', array('status' => 401));
    }

}


///// WEBHOOK //////

function handle_webhook_request($request){

    global $wpdb;
    $table_name = $wpdb->prefix . 'api_settings';

    $ime = 'webhook';
    $id = $_POST['form']['id'];

    $sql = $wpdb->prepare(
        "SELECT * FROM $table_name WHERE name = %s AND value = %s", $ime, $id );

    $result = $wpdb->get_results($sql);

    if (!empty($result)){


        //// DODATI LOGIKU! ////
    
        return array('status' => 'success');

    }else{
        return new WP_Error('unauthorized', 'Unauthorized', array('status' => 401));
    }
    
}


function check_verification($request) {
   
    $jwt = $request->get_header('Authorization');

    // Provera da li je JWT token prisutan
    if (!$jwt) {
        return false;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'api_users';

    $jwt = str_replace('Bearer ', "", $jwt);

    // Izvršavanje SQL upita da pronađe ID korisnika sa datim JWT tokenom
    $user_id = $wpdb->get_var($wpdb->prepare("SELECT ID FROM $table_name WHERE jwt_token = %s", $jwt));

    // Provera da li je pronađen ID korisnika i da li je aktiviran
    if ($user_id !== null) {
        $activated = $wpdb->get_var($wpdb->prepare("SELECT activated FROM $table_name WHERE ID = %d", $user_id));

        if ($activated == 1) {
            return true;
        }
    }

    return false;
}