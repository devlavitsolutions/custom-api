<?php

require plugin_dir_path(__FILE__) . '../../vendor/autoload.php';
use Firebase\JWT\JWT;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


function generate_jwt_token($email) {
    // Definišite ključ za potpisivanje tokena
    $secretKey = 'tajni-kod-za-potpisivanje';

    // Definišite podatke koje želite ugrađivati u token
    $payload = [
        'email' => $email,
        'exp' => time() + 3600, // Vreme isteka tokena (ovde 1 sat od trenutka generisanja)
    ];

    // Generišite JWT token pomoću biblioteke firebase/php-jwt
    $jwt_token = JWT::encode($payload, $secretKey, 'HS256');

    return $jwt_token;
}

function generate_activation_code(){
    return bin2hex(random_bytes(16));
}

function send_email($email, $subject, $body){
    
    try{
        $mail = new PHPMailer(true);

        //Postavke maila
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'djangopython2000@gmail.com';
        $mail->Password = 'nqnwuxqlxtehdvso';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('djangopython2000@gmail.com', 'Lav IT Solutions');
        $mail->addAddress($email);

        $mail->isHTML(true);
        
        $mail->Subject = $subject;
        $mail->Body = $body;

        $mail->send();

    } catch (Exception $e) {
        echo "Poruka nije mogla biti poslata: {$mail->ErrorInfo}";
    }

    
}

function registracija_jwt() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
        $email = sanitize_email($_POST['email']);
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'api_users';

        $existing_user = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE email = %s", $email));
        if($existing_user){
            echo 'Ne mozete se registrovati ovim mailom';
            return;
        }

        //Generisanje aktivacionog koda
        $activation_code = generate_activation_code();

        // Upisivanje u bazu
        $wpdb->insert(
            $table_name,
            array(
                'email' => $email,
                'activation_code' => $activation_code,
            ),
            array('%s', '%s')
        );

        //Slanje maila
        $user_id = $wpdb->insert_id;

        $subject = 'Verifikacija e-mail adrese'; 

        $activation_link = home_url("/verify/?id=$user_id&code=$activation_code");
        $body = 'Ako ste ovo Vi kliknite na sledeći link kako biste verifikovali svoju e-mail adresu: ' . $activation_link;

        send_email($email, $subject, $body);

        echo 'Link za verifikaciju je poslat na Vas email';
        exit;
    }
}

/////////////// REGISTRATION PAGE ////////////////////////////
function add_registration_page() {
    // Dodajte pravilo za preusmeravanje
    add_rewrite_rule('^registracija/?$', 'index.php?custom_api_registration=1', 'top');
}

function register_query_vars($vars) {
    // Registrujte query varijablu za preusmeravanje
    $vars[] = 'custom_api_registration';
    return $vars;
}

function add_registration_page_to_menu() {
    // Dodajte stranicu "Registracija" u meni ako već ne postoji
    $page_id = get_option('custom_api_registration_page_id');
    if (!$page_id) {
        $page = array(
            'post_title' => 'Registracija',
            'post_status' => 'publish',
            'post_type' => 'page',
        );
        $page_id = wp_insert_post($page);
        update_option('custom_api_registration_page_id', $page_id);
    }
}


function template_include($template) {
    // Prikazivanje stranice za registraciju kada je query varijabla prisutna
    if (get_query_var('custom_api_registration')) {
        return dirname(dirname(dirname(__FILE__))) . '\pages\registration-page.php';
    }
    return $template;
}



?>