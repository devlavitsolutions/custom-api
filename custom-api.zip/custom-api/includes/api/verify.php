<?php

//// OBRADA VERIFIKACIONOG KODA ////

if (isset($_GET['code']) && isset($_GET['id'])) {
    $activation_code = sanitize_text_field($_GET['code']);
    $user_id = intval($_GET['id']);

    global $wpdb;
    $table_name = $wpdb->prefix . 'api_users';

    $query = $wpdb->prepare("SELECT * FROM $table_name WHERE ID = %d", $user_id);
    $user = $wpdb->get_row($query);
    
    if ($user) {

        if($user->activated == 0) {
            $stored_activation_code = $user->activation_code;

            if ($activation_code === $stored_activation_code) {

                $wpdb->update(
                    $table_name,
                    array('activated' => 1),
                    array('ID' => $user_id),
                    array('%d'),
                    array('%d')
                );
            

                $email = $user->email;
                $jwt_token = generate_jwt_token($email);

                $wpdb->update(
                    $table_name,
                    array('jwt_token' => $jwt_token),
                    array('ID' => $user_id),
                    array('%s'),
                    array('%d')
                );

                $subject = 'Vas Json Web Token';
                $body = 'Vas JWT: ' . $jwt_token;
                send_email($email, $subject, $body);
                echo 'Uspešno ste verifikovali svoj nalog. Vaš JWT token je poslat na vašu e-mail adresu.';

                exit;

            } else {
                echo 'Aktivacioni kod nije validan.';
            }

        }else{
            echo 'Korisnik je vec verifikovan.';
        }

    } else {
        echo 'Korisnik nije pronađen.';
    }
} 

?>
