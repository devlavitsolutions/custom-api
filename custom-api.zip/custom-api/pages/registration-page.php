<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registracija</title>
    </head>
    <body>
        <h1>Registracija</h1>
        <form method="post" action="">
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>
            <br>
            <input type="submit" value="Registruj se">
        </form>
    </body>
    </html>