<?php

/*
Plugin Name: Custom API 
Description: A plugin that enables the creation of articles through POST requests and user registration via API. Manage and configure API endpoints and settings.
Version: 1.0
Author: Lav IT Solutions
*/

if( !function_exists('add_action') ){
    echo 'Not allowed';
    exit;
}


//// INCLUDES ////
include('includes/api/api-functions.php');
include('includes/admin/admin-functions.php');
include('includes/database/database-functions.php');
include('includes/api/registration-functions.php');
include('includes/api/verify.php');


//// HOOKS ////

// API
add_action('rest_api_init', 'register_api_endpoints');
register_activation_hook(__FILE__, 'logs_api_create_table');
// Admin
add_action('admin_menu', 'custom_api_menu_page');
add_action('admin_init', 'custom_api_settings_init');
add_action('admin_menu', 'custom_api_submenu_page');
add_action('admin_enqueue_scripts', 'custom_enqueue_admin_scripts');
add_action('admin_enqueue_scripts', 'custom_localize_script', 11);
add_action('admin_menu', 'custom_api_delete_edit_submenu_page');
add_action('admin_init', 'custom_api_delete_log');
add_filter('plugin_action_links_custom-api/index.php', 'custom_add_deactivation_class');
add_action('wp_ajax_delete_custom_table', 'ajax_delete_custom_table');
// Registracija
add_action('init', 'registracija_jwt');
add_action('init', 'add_registration_page');
add_filter('query_vars', 'register_query_vars');
add_action('init', 'add_registration_page_to_menu');
add_filter('template_include', 'template_include');


?>
